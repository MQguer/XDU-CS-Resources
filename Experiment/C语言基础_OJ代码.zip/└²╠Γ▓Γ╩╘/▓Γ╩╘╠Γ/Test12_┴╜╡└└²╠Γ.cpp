#include <stdio.h>

int main(){
	int a=0, b=4;
	
	if(a=b) printf("a=b");
	
	
	
	

	return 0;
}
