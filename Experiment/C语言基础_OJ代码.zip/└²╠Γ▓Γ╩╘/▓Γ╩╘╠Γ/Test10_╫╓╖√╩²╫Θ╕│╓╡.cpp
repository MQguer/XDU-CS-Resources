#include <stdio.h>

int main(){
	char a[30] = {"Beijing"};
	
	char b[] = "Beijing";
	
	//char c[30];
	//c = "Beijing";
	
	char d[30] = {'B','e','i','j','i','n','g'};
	
	return 0;
}
