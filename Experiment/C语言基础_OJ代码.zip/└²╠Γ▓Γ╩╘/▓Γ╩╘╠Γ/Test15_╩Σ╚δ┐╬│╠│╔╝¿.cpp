#include <stdio.h>


//����δ���
 
int main(){
	
	char course[8][256] = {'\0'};
	
	int i = 0;
	int j = 0;
	
	for(i=0; i<=7; i++){
		scanf("%s",&course[i][]);
	} 
	
	return 0;
}
