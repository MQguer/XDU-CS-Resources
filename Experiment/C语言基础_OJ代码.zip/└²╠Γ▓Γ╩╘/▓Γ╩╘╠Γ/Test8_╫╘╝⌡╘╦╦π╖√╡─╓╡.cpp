#include <stdio.h>

int main(){
	int i = 1;
	while(i--){
		printf("%d\n",i);
	}
	return 0;
}
