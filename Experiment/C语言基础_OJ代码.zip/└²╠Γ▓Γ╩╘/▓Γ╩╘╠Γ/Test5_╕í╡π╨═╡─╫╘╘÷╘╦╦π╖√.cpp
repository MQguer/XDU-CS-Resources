#include<stdio.h>

int main(){
	
	//int x,a;
	
	//scanf_s("%d",&x);
	
	//a = (x%100==0)||(x%4==0&&x%100!=0);

	//printf("%d",a);
	
	float x,y;
	
	x = 0.1000;
	y = ++x;
	
	printf("%lf",y);
	
	return 0;
}
