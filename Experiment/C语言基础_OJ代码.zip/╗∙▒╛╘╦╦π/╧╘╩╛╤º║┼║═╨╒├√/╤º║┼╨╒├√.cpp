#include <stdio.h>
#include <stdlib.h>
int main()
{
    printf("�ι��� 19030500141\n");
    
    system("pause");
    
    return 0;
}
