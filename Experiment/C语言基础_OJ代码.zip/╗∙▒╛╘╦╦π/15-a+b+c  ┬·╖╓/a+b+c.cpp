#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main(void)
{
    int a=0;
    int b=0;
    int c=0; 
    int d=0;  
    scanf("%d %d %d",&a,&b,&c);
    d=a+b+c;
    printf("%d",d);
    return 0;
} 
