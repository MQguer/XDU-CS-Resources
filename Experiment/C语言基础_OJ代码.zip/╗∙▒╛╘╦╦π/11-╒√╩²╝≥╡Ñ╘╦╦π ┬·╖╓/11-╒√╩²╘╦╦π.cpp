#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
	int a,b,s,d,m,q;
	scanf("%d %d",&a,&b);
	s=a+b;
	d=a-b;
	m=a*b;
	q=a/b;
	printf("%d\n%d\n%d\n%d\n",s,d,m,q); //�Ͳ���� 
	return 0; 
}
