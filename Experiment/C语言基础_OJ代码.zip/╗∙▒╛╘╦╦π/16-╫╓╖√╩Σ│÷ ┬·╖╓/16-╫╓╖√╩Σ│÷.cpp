#include <stdio.h>
#include <stdlib.h>

int main()
{
    char a=0;
    char b=0;
    char c=0;
    char d=0;
    char e=0;
    scanf("%c|%c|%c|%c|%c",&a,&b,&c,&d,&e);
    printf("%c%c%c%c%c!",a+32,b+32,c+32,d+32,e+32);
    return 0;
}
