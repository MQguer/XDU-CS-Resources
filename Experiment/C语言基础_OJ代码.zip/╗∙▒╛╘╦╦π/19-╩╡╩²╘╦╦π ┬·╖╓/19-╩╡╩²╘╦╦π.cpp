#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
	float a,b,c,V; 
	scanf("%f %f %f",&a,&b,&c);
	V=a*b*c*1.000;
	printf("%.3f",V);
	return 0;
}
