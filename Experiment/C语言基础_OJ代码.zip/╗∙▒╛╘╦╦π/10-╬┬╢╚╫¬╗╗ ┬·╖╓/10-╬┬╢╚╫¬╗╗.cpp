#include <stdio.h>

int main()
{
	int m = 0;
	scanf("%d",&m);
	
	double t = 5.00*(m-32.00)/9;
	printf("%.2f",t);
	
	return 0;
}
