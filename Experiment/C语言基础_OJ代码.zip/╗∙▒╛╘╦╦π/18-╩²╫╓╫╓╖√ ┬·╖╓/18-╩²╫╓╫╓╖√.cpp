#include <stdio.h>
#include <stdlib.h>

int main ()
{
    int a=0;
    char b=0;
    int c=0;
    char d=0;
    
    scanf("%d,%c",&a,&b);
    
    
    c=a+b;
    d=a+b;
    printf("%d,%c",c,d);
    
    return 0;
}
    
    
