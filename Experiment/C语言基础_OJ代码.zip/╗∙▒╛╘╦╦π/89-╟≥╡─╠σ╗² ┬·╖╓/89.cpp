#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
    double r,V;
    double pi=3.14;
    scanf("%lf",&r);
    V=(4.0/3)*pi*r*r*r;
    printf("%.2lf",V);
    return 0;
}
    
