#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
int main()
{
	char x[100]={0};
	scanf("%s",x);
	int n=strlen(x);
	printf("%d",n);
	
	return 0;
}
